const axios = require('axios')
const url = `https://dinosaur-facts-api.shultzlab.com/dinosaurs` 

const dinosaurs = async() => {
    const response = await axios.get(url)
    let arreglo = response.data
    arreglo.forEach((dinosaur) => {
        console.log(dinosaur.name)
        console.log("Holii")
}
)}

dinosaurs()